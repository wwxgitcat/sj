<?php

/**
 * data
 * @author auto create
 */
class Data
{
	
	/** 
	 * data
	 **/
	public $data;	
}
?>